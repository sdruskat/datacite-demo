# datacite-demo

HERMES demo repository for the DataCite webinar `DOIs for Research Software: Increasing Visibility, Connectivity, Citability`.
